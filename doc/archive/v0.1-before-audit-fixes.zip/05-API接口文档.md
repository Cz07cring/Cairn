# API 接口文档

> **设计契约，所有路由尚未实现。** 本文件定义 ringharness 控制 API，不代表 DeepSeek Harness 自带 HTTP API。字段变更须同步 [开发](01-开发文档.md)、[前端](04-前端文档.md) 与生成客户端。

## 1. 通用约定

公共业务前缀 `/api/v1`，内部前缀 `/internal/v1`。JSON 为 UTF-8；字段 snake_case；路径 kebab-case；日期 RFC3339 UTC；ID 为 UUID；sha256 为完整摘要；fencing_token 用十进制字符串。拒绝未知写入字段，字符串长度、数组大小和数字边界由 schema 校验。

同步创建返回 201；同步查询/更新 200；异步控制返回 202 Operation。所有变更都必须提供 `Idempotency-Key`，作用域为 project+principal+method+规范化 path；无项目操作（建项目、登出）使用 principal+method+path；同 key 同 body 返回首次结果，同 key 不同 body 返回 409。任务生命期内不回收幂等记录，终态后至少保存 30 天。请求超时只能用原 key 重查/重试，不能换 key。

需要版本的更新提供 JSON `expected_revision`；计划提交用 `expected_plan_revision`。版本不符返回 409，不执行任何部分更新。所有列表支持 `cursor`（不透明游标）、`limit`（默认 50，1—200），稳定排序 created_at+id；过滤条件变化必须清空 cursor。

```json
{
  "data": {"id":"11111111-1111-4111-8111-111111111111","status":"DRAFT","revision":1},
  "error": null,
  "meta": {"request_id":"22222222-2222-4222-8222-222222222222"}
}
```

分页在 meta 中增加 `next_cursor: string|null`；错误时 data=null，error={code,message,details,retryable}；details 仅允许 field、current_revision、operation_id 等安全字段，不返回堆栈/密钥/宿主路径。

| HTTP | code 示例 | 客户端动作 |
|---|---|---|
| 400 | INVALID_CURSOR / INVALID_REQUEST | 修正输入 |
| 401 | UNAUTHENTICATED | 统一登录，仅跳转一次 |
| 403 | FORBIDDEN / POLICY_DENIED | 显示原因，不重试 |
| 404 | NOT_FOUND | 包括跨项目不可见资源，避免泄露存在性 |
| 409 | REVISION_CONFLICT / IDEMPOTENCY_CONFLICT / INVALID_STATE / FENCING_REJECTED | 刷新并解释冲突；不得自动改正文重发 |
| 410 | EVENT_CURSOR_EXPIRED | 获取 snapshot 后重新订阅 |
| 413 | PAYLOAD_TOO_LARGE | 缩小输入或用工件流 |
| 422 | VALIDATION_ERROR / DAG_CYCLE / MODEL_OUTPUT_INVALID | 定位字段/无效结构 |
| 429 | RATE_LIMITED | 尊重 Retry-After；保留未知状态 |
| 503 | DEPENDENCY_UNAVAILABLE | 显示降级；有限重试只读请求 |

默认请求 JSON 上限 1MiB；合同 objective 1—10000 字符，criterion 1—200 条，单计划最多 1000 节点/10000 边。超限应提示分规划 epoch，不能静默截断。

## 2. 身份与授权

浏览器采用同源 HttpOnly Secure SameSite=Lax session cookie。POST/PUT/PATCH/DELETE 均验证 CSRF token 与 Origin；本地开发 HTTPS 可由反向代理提供。默认不开放跨域。CLI 用短期 Bearer 凭据，浏览器不保存 Bearer/Service Key 到 localStorage。具体 OIDC 身份源待部署确定，采用固定 allowlist issuer/audience。

角色：viewer 读项目；operator 创建/控制自己有权限的 Goal；approver 批准授权变更；admin 管理项目/策略/模型与 Skill。角色权限可组合，但 Worker、Auditor 使用独立内部 workload 身份，不可借浏览器角色执行内部写入。

每个端点都检查 resource.project_id 与主体范围；装饰器 import 不证明已鉴权，必须有真实依赖/middleware 测试。GET `/health/live` 是唯一无身份健康端点，仅返回 alive，不暴露依赖详情；`/health/ready`、`/metrics` 仅运维网络 workload 身份可访问。

## 3. 请求与响应模型

表内 `?` 表示可省略，并注明默认；未标记均必填。null 与省略区别由类型固定，不能用空串替代。只读 Resource 由服务端生成 id、revision、created_at、updated_at，客户端不得自设状态。

### 3.1 基础模型

| 模型 | 字段（类型 / 约束） |
|---|---|
| Criterion | id:string（Goal 内稳定唯一）、description:string、verifier_ref:string（批准验证器 ID）、required:bool；verifier_ref 不接受任意宿主 shell |
| Budget | wall_clock_seconds:int>0、max_tokens:int≥0、max_cost_usd:decimal-string≥0、max_attempts:int≥1、max_tool_calls:int≥0、max_network_calls:int≥0、max_disk_bytes:int≥0、max_gpu_seconds:int≥0|null（null=不设硬限制，仍记录可得用量） |
| Resources | cpu_millicores:int>0、memory_bytes:int>0、disk_bytes:int>0、model_slots:int≥0、browser_slots:int≥0、exclusive_labels:string[] |
| GoalCreate | project_id:uuid、objective:string、success_criteria:Criterion[]、constraints:string[]、budget:Budget、policy_id:uuid、model_profile_id:uuid、skill_set_id:uuid、base_commit:string |
| GoalContractUpdate | expected_revision:int、contract:GoalCreate（project_id 不可变）、reason:string；仅 DRAFT/PAUSED 可提交，新版本 |
| GoalResource | id、project_id、status（01 的 Goal 枚举）、revision、contract_revision、plan_revision:int|null、contract:GoalCreate、previous_status:string|null、integration_commit:string|null、criterion_summary:{verified:int,total:int}、budget_usage:object、block_reason:string|null、created_at、updated_at |
| TaskContract | objective:string、depends_on:uuid[]、input_artifact_ids:uuid[]、deliverables:{kind:string,required:bool}[]、acceptance:Criterion[]、allowed_paths:string[]、protected_paths:string[]、required_capabilities:string[]、budget:Budget、resources:Resources、risk:low/medium/high |
| PlanCreate | expected_plan_revision:int|null、reason:string、tasks:{id:uuid,contract:TaskContract,replaces_task_id?:uuid}[]；为完整候选图，不是盲 patch；id 可由规划器预分配以表达边 |
| PlanResource | id、goal_id、plan_revision:int、status:CANDIDATE/PUBLISHED/REJECTED、reason、tasks、created_at；发布失败存拒绝原因，旧计划不变 |
| TaskResource | id、goal_id、contract:TaskContract、contract_revision、plan_revision、revision、status（01 的 Task 枚举）、block_reason:string|null、resume_state:string|null、attempt_count:int、latest_checkpoint_id:uuid|null、replaces_task_id:uuid|null、created_at、updated_at |
| ControlRequest | expected_revision:int、reason:string；reason 非空，1—2000 字符 |
| ReplanRequest | expected_revision:int、expected_plan_revision:int|null、reason:string |
| OperationResource | id、project_id、goal_id:uuid|null、task_id:uuid|null、kind:string、status:ACCEPTED/RUNNING/SUCCEEDED/FAILED/UNKNOWN、request_hash:string、result:object|null、error:object|null、external_ref:string|null、created_at、updated_at |
| ApprovalDecision | expected_revision:int、decision:APPROVE/DENY、request_hash:string、reason:string；批准范围从原请求读取，不允许客户端扩张 |
| ApprovalResource | id、project_id、goal_id、task_id:uuid|null、revision、kind、request_hash、scope:object、estimated_cost_usd:string、data_categories:string[]、expires_at、status:PENDING/APPROVED/DENIED/EXPIRED/REVOKED、decision_reason:string|null |
| AttemptResource | id、task_id、revision:int、phase:execute/audit、status:ACTIVE/COMPLETED/FAILED/EXPIRED/CANCELLED、worker_id、fencing_token:string、lease_expires_at、context_hash:string|null、model_snapshot:object、skill_versions:object[]、started_at、finished_at:string|null |

GoalCreate 示例（UUID 和 commit 为占位数据，不代表真实资源）：

```json
{
  "project_id":"11111111-1111-4111-8111-111111111111",
  "objective":"修复示例仓库断线重连问题并验证",
  "success_criteria":[{"id":"C1","description":"独立重连验收套件通过","verifier_ref":"reconnect-suite-v1","required":true}],
  "constraints":["仅允许修改隔离工作区","不访问生产服务"],
  "budget":{"wall_clock_seconds":432000,"max_tokens":10000000,"max_cost_usd":"0.00","max_attempts":200,"max_tool_calls":10000,"max_network_calls":1000,"max_disk_bytes":10737418240,"max_gpu_seconds":null},
  "policy_id":"33333333-3333-4333-8333-333333333333",
  "model_profile_id":"44444444-4444-4444-8444-444444444444",
  "skill_set_id":"55555555-5555-4555-8555-555555555555",
  "base_commit":"aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa"
}
```

max_cost_usd=0 表示不允许付费模型，并不把本地硬件能耗认作零。

### 3.2 辅助模型

| 模型 | 字段 |
|---|---|
| ProjectCreate | name:string、repository_ref:string（预登记仓库引用，不能任意宿主路径） |
| ProjectResource | id、name、repository_ref、revision、created_at、updated_at |
| PolicyCreate | name、allowed_tools:string[]、allowed_paths:string[]、protected_paths:string[]、network_allowlist:string[]、external_actions:{action:string,mode:DENY/ALLOW/APPROVAL}[]、secret_scope_refs:string[]；仅引用，不含密钥 |
| PolicyResource | id、version、content_hash、config:PolicyCreate、created_at |
| ModelProfileCreate | name、local_provider_ref、model_id、context_window:int、output_reserve:int、inference_slots:int、cloud_provider_refs:string[]、cloud_mode:DENY/PREAUTHORIZED/APPROVAL；provider_ref 来自部署 allowlist |
| ModelProfileResource | id、version、config:ModelProfileCreate、capability_status:UNVERIFIED/VERIFIED/FAILED、probe_evidence_ids:uuid[] |
| SkillCreate | name、source_ref（登记源）、content_artifact_id:uuid、capabilities:string[]、role_scopes:string[]、required_tools:string[] |
| SkillVersionResource | id、skill_id、version、content_hash、config:SkillCreate、status:CANDIDATE/VALIDATING/ACTIVE/REVOKED/REJECTED、audit_id:uuid|null |
| SkillSetCreate | name、skill_version_ids:uuid[]（全部 ACTIVE） |
| SkillSetResource | id、version、name、skill_version_ids、created_at |
| ArtifactResource | id、project_id、digest、size_bytes:int、mime:string、created_at、producer_identity；存储 key 不暴露 |
| EvidenceResource | id、task_id、attempt_id、producer_identity、command_argv:string[]、cwd_ref、exit_code:int|null、started_at、finished_at:string|null、stdout_artifact_id、stderr_artifact_id、candidate_commit:string|null、environment_hash、truncated:bool |
| AuditResource | id、task_id、attempt_id、layer:MECHANICAL/SEMANTIC/ADVERSARIAL/GLOBAL、verdict:PASS/INSUFFICIENT/FAIL、criterion_results:{criterion_id,verdict,evidence_ids:uuid[],reason}[]、evidence_ids:uuid[]、candidate_commit:string|null、contract_revision:int、reason |
| MemoryResource | id、project_id、kind:fact/decision/failure/hypothesis/question、statement、source_evidence_ids:uuid[]、status:PROPOSED/VERIFIED/SUPERSEDED、confidence:number、valid_from、supersedes_id:uuid|null |
| ReconciliationRequest | expected_revision:int、observed_result:SUCCEEDED/FAILED、external_ref:string、evidence_ids:uuid[]、reason:string；仅 UNKNOWN，证据验证后才改变状态 |

### 3.3 运行状态补充模型

| 模型 | 精确字段 |
|---|---|
| BudgetUsage | consumed_tokens:int、reserved_tokens:int、consumed_cost_usd:string、reserved_cost_usd:string、cost_status:CONFIRMED/ESTIMATED/UNKNOWN、elapsed_wall_seconds:int、active_seconds:int、tool_calls:int、network_calls:int、disk_bytes:int、gpu_seconds:number|null、observed_at:string |
| Checkpoint | id:uuid、task_id:uuid、attempt_id:uuid、phase:string、completed_steps:string[]、next_step:string、workspace_manifest_hash:string、git_commit:string|null、session_ref:string|null、artifact_ids:uuid[]、operation_ids:uuid[]、schema_version:int、created_at:string |
| ComponentStatus | name:string、state:HEALTHY/DEGRADED/UNAVAILABLE/UNKNOWN、observed_at:string、reason_code:string|null；不暴露凭据或内部地址 |
| ResourceStatus | model:{used:int,total:int}、tools:{used:int,total:int}、browsers:{used:int,total:int}、queued_tasks:int、observed_at:string、stale:bool |

GoalResource.budget_usage 使用 BudgetUsage；system/status 的 components 使用 ComponentStatus[]，resources 使用 ResourceStatus。OperationResource.result 是按 kind 区分的联合类型：控制命令 `{goal_id,final_status}`；任务重做 `{replacement_task_id}`；模型探测 `{profile_id,evidence_ids,capability_status}`；Skill 验证 `{version_id,audit_id,verdict}`；外部工具 `{external_ref,evidence_ids}`。未完成时 result=null；不能让客户端自行解析自然语言摘要作为成功结果。完整联合类型在首次 OpenAPI 生成时落实。

## 4. 公共 HTTP 路由清单

角色缩写 V=viewer，O=operator，A=approver，M=admin。更高角色不自动绕过项目 scope。`List<X>` 均用 data 数组和 meta.next_cursor。

| 方法与完整路径 | 角色 | 请求 / 过滤 | 返回 | 主要调用方 |
|---|---|---|---|---|
| GET /api/v1/auth/login | 公开入口 | return_to（仅同源允许路径） | 302 身份源 | 登录页 |
| GET /api/v1/auth/callback | OIDC 回调 | code,state，校验 PKCE/nonce | 302 + session cookie | 身份源 |
| GET /api/v1/auth/session | 已登录 | 无 | 200 {user_id,roles,project_ids,csrf_token,expires_at} | AppShell |
| POST /api/v1/auth/logout | 已登录 | {} + CSRF | 200 {logged_out:true} | 账户菜单 |
| GET /api/v1/projects | V | cursor,limit | List<ProjectResource> | 项目切换 |
| POST /api/v1/projects | M | ProjectCreate | 201 ProjectResource | 管理页 |
| GET /api/v1/goals | V | project_id 必填；status,cursor,limit | List<GoalResource> | 目标列表 |
| POST /api/v1/goals | O | GoalCreate | 201 GoalResource | 创建目标 |
| GET /api/v1/goals/{goal_id} | V | 无 | GoalResource | 目标详情 |
| PUT /api/v1/goals/{goal_id}/contract | O | GoalContractUpdate | GoalResource | 编辑合同 |
| POST /api/v1/goals/{goal_id}/start | O | ControlRequest | 202 OperationResource | 合同确认 |
| POST /api/v1/goals/{goal_id}/pause | O | ControlRequest | 202 OperationResource | 目标控制 |
| POST /api/v1/goals/{goal_id}/resume | O | ControlRequest | 202 OperationResource | 目标控制 |
| POST /api/v1/goals/{goal_id}/cancel | O | ControlRequest | 202 OperationResource | 取消流程 |
| POST /api/v1/goals/{goal_id}/replan | O | ReplanRequest | 202 OperationResource | 重新规划 |
| GET /api/v1/goals/{goal_id}/plans | V | cursor,limit | List<PlanResource> | 计划历史 |
| POST /api/v1/goals/{goal_id}/plans | O | PlanCreate | 201 PlanResource | 人工计划编辑；同样校验 |
| GET /api/v1/goals/{goal_id}/tasks | V | status,cursor,limit | List<TaskResource> | DAG / 表格 |
| GET /api/v1/tasks/{task_id} | V | 无 | TaskResource | 任务详情 |
| POST /api/v1/tasks/{task_id}/cancel | O | ControlRequest | 202 OperationResource | 任务控制 |
| POST /api/v1/tasks/{task_id}/retry | O | ControlRequest | 202 OperationResource，result 含 replacement_task_id | 显式重做，创建 replacement，不复活终态 |
| GET /api/v1/tasks/{task_id}/attempts | V | cursor,limit | List<AttemptResource> | 执行历史 |
| GET /api/v1/tasks/{task_id}/checkpoints | V | cursor,limit | List<Checkpoint>（01） | 恢复详情 |
| GET /api/v1/tasks/{task_id}/evidence | V | cursor,limit | List<EvidenceResource> | 证据页 |
| GET /api/v1/tasks/{task_id}/audits | V | cursor,limit | List<AuditResource> | 审计页 |
| GET /api/v1/artifacts/{artifact_id} | V | 无 | ArtifactResource | 工件详情 |
| GET /api/v1/artifacts/{artifact_id}/content | V | Range? | 200/206 二进制，ETag=digest | 工件查看/下载 |
| GET /api/v1/operations | V | project_id 必填；idempotency_key?,goal_id?,status?,cursor,limit | List<OperationResource>；key 查询限原主体 | 未收到 operation_id 时核对 |
| GET /api/v1/operations/{operation_id} | V | 无 | OperationResource | 控制命令进度 |
| POST /api/v1/operations/{operation_id}/reconcile | A | ReconciliationRequest | 202 OperationResource | 未知结果核对 |
| GET /api/v1/approvals | V | project_id 必填；status?,cursor,limit | List<ApprovalResource> | 待处理中心 |
| POST /api/v1/approvals/{approval_id}/decision | A | ApprovalDecision | ApprovalResource | 授权决策 |
| GET /api/v1/policies | V | project_id,cursor,limit | List<PolicyResource> | 合同编辑 |
| POST /api/v1/policies | M | PolicyCreate + project_id | 201 PolicyResource，新版本独立 ID | 管理页 |
| GET /api/v1/model-profiles | V | project_id,cursor,limit | List<ModelProfileResource> | 模型设置 |
| POST /api/v1/model-profiles | M | ModelProfileCreate + project_id | 201 ModelProfileResource | 管理页 |
| POST /api/v1/model-profiles/{profile_id}/probe | M | {} | 202 OperationResource | 能力检测 |
| GET /api/v1/skills | V | project_id,status?,cursor,limit | List<SkillVersionResource> | Skill 库 |
| POST /api/v1/skills | M | SkillCreate + project_id | 201 SkillVersionResource | 登记候选 |
| POST /api/v1/skills/{version_id}/validate | M | {} | 202 OperationResource | Skill 验证 |
| POST /api/v1/skills/{version_id}/activate | M | {audit_id:uuid,reason:string} | SkillVersionResource；必须验证 PASS | Skill 发布 |
| POST /api/v1/skills/{version_id}/revoke | M | {reason:string} | SkillVersionResource | 紧急撤销 |
| GET /api/v1/skill-sets | V | project_id,cursor,limit | List<SkillSetResource> | 合同编辑 |
| POST /api/v1/skill-sets | M | SkillSetCreate + project_id | 201 SkillSetResource | 管理页 |
| GET /api/v1/memories | V | project_id,kind?,q?,cursor,limit | List<MemoryResource> | 事实/失败记录 |
| GET /api/v1/system/status | V | project_id | {components:object[],resources:object,observed_at,stale:bool} | 概览 |
| GET /api/v1/goals/{goal_id}/snapshot | V | 无 | {goal,plan,tasks,approvals,operations,latest_seq} | 实时恢复 |
| GET /api/v1/goals/{goal_id}/events | V | after_seq?,limit? | text/event-stream | 目标实时页 |

auth/login 和 callback 为身份流程例外，不是公开业务数据。artifact/content 响应为文件流，不套 JSON envelope；active HTML/SVG 强制下载或隔离域，nosniff，不能在同源直接执行。没有通用“任意状态 patch”、任意命令执行或强制 DONE 端点。

## 5. 事件协议与重连

SSE 使用同源 cookie，事件数据不可携带密钥。event.id 为 Goal 内 seq 的十进制字符串；数据包含 event_id、goal_id、seq、type、entity_id、entity_revision、occurred_at、payload。事件类型至少包括 GOAL_STATE_CHANGED、PLAN_PUBLISHED、TASK_STATE_CHANGED、ATTEMPT_STARTED、CHECKPOINT_CREATED、EVIDENCE_CREATED、AUDIT_RECORDED、OPERATION_CHANGED、APPROVAL_REQUIRED、BUDGET_CHANGED、SKILL_REVOKED。

```text
id: 42
event: TASK_STATE_CHANGED
data: {"event_id":"66666666-6666-4666-8666-666666666666","goal_id":"77777777-7777-4777-8777-777777777777","seq":"42","type":"TASK_STATE_CHANGED","entity_id":"88888888-8888-4888-8888-888888888888","entity_revision":8,"occurred_at":"2026-09-11T03:00:00Z","payload":{"status":"VERIFYING"}}
```

服务每 15s 发送注释心跳；客户端 45s 无事件/心跳显示 stale。首次 snapshot 在一致读事务中返回完整当前视图和 latest_seq；再以 after_seq 订阅。服务保留活动 Goal 全历史，终态至少 30 天热事件。Last-Event-ID 和 after_seq 同时出现且不同则 400；过期游标 410 后重新 snapshot。

重连按 1/2/4/8/30s 上限退避，事件重复按 event_id 去重；低 entity_revision 不覆盖新状态；seq 缺口重取 snapshot。正常业务事件不作为原始日志传输，日志以工件分段读取，避免浏览器无界增长。服务器慢消费者超缓冲上限则断开，客户端凭游标恢复。

## 6. 内部 Worker 与 Harness adapter 协议

以下端点必须 workload 身份认证并绑定 worker_id/role；只允许内网或 Unix socket。Runner 无直连业务数据库权限。每个变更同样需要 Idempotency-Key；除 claim 外所有 attempt 请求体都有 `attempt_id, fencing_token, expected_revision`，此处 expected_revision 指 AttemptResource.revision；同 attempt 的心跳与提交串行化，冲突先刷新 lease。工件流用等价请求头传递这三个字段。

| 路由 | 请求字段（公共字段外） | 返回 / 约束 |
|---|---|---|
| POST /internal/v1/claims | worker_id,phase,capabilities:string[],resource_capacity:Resources | {lease:null} 或 {lease:{task,attempt,contract,policy_snapshot,context_refs}}；领取与预留原子化 |
| POST /internal/v1/attempts/{attempt_id}/heartbeat | 无 | {lease_expires_at,revision,control:CONTINUE/CHECKPOINT/STOP}；过期不能续租 |
| POST /internal/v1/attempts/{attempt_id}/checkpoints | phase,completed_steps:string[],next_step,workspace_manifest_hash,git_commit:string|null,session_ref:string|null,artifact_ids:uuid[],operation_ids:uuid[],schema_version:int | 201 Checkpoint；引用必须已持久化 |
| POST /internal/v1/attempts/{attempt_id}/submit | candidate_commit:string|null,evidence_ids:uuid[],artifact_ids:uuid[],summary:string | 202 OperationResource；进入 VERIFYING，不允许指定 DONE |
| POST /internal/v1/attempts/{attempt_id}/fail | failure_class,signature,evidence_ids:uuid[],retry_hint:string | TaskResource；controller 决定重试/升级 |
| POST /internal/v1/attempts/{attempt_id}/audits | AuditResource 的业务字段（不含 id） | 201 AuditResource；仅 auditor 角色可写，task/attempt 与 URL 一致 |
| POST /internal/v1/tool-operations | task_id,attempt_id,fencing_token,expected_revision,tool_name,input:object,policy_version | 202 OperationResource；gateway 校验权限，任意 shell 输入受沙箱约束 |
| POST /internal/v1/tool-operations/{operation_id}/result | attempt_id,fencing_token,expected_revision,exit_code:int|null,artifact_ids:uuid[],external_ref:string|null,outcome:SUCCEEDED/FAILED/UNKNOWN | OperationResource；仅签发该操作的可信网关；失租结果留作 reconciliation，不写任务成功 |
| PUT /internal/v1/artifacts/{digest}/content | 二进制；头携 project_id,attempt_id,fencing_token,expected_revision | 201 ArtifactResource；流式校验 sha256/配额，禁止覆盖不一致内容 |
| POST /internal/v1/goals/{goal_id}/plans | PlanCreate | PlanResource；仅 planner workload，不能绕过图校验 |
| POST /internal/v1/goals/{goal_id}/final-audits | contract_revision,plan_revision,integration_commit,criterion_results,evidence_ids | 201 AuditResource；仅 Global Critic；controller 最终 CAS |
| POST /internal/v1/memories | project_id,task_id,kind,statement,source_evidence_ids,confidence | 201 MemoryResource(PROPOSED)；验证后由记忆服务晋升 |

可信网关提交 result 时，Evidence 服务从原 tool operation 的 argv/cwd/版本、可信开始结束时间和返回工件构建 EvidenceResource，不能接受模型提供的 producer_identity。

Artifact 大流上传先授权再流式限额；超时重用 digest 查询元数据可核对。外部结果在失租后仍可送到 reconciliation 通道，但必须保持原 attempt、operation 和来源，不能抢占新 Worker 状态。

Adapter 内部调用协议（设计，不是上游原生函数名）：activate(TaskLease, ContextBundle)→ActivationRef；request_checkpoint(ActivationRef)→CheckpointProposal；stop(ActivationRef, reason)→StopReceipt；events(ActivationRef,cursor)→AsyncIterator<RuntimeEvent>。RuntimeEvent 包含 activation_id、seq、type、payload_ref；所有映射测试绑定上游 commit。上游 session continuation 是否适用某场景须实际验证，失败可重建 session。

## 7. 实现与兼容验收

后端 Pydantic schema → OpenAPI → TypeScript client → E2E。禁止前端再手写一套 enum。PR 检查：实际路由集合等于文档集合；每个字段、默认值、nullable、权限、错误码与 OpenAPI 对齐；含 PUT/PATCH、内部接口、模型字段与数据库迁移。路由未找到调用方时标记为预留设计并说明用途，不自动删除公开接口。

服务端只在 policy+版本+预算都检查成功后调度；202 只说明命令入库。批量请求逐条结果不得掩盖部分失败。API 兼容性破坏必须新版本或显式迁移，不靠客户端忽略字段解决。
