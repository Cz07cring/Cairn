// Independent JavaScript encoding of valid fixed vectors, not an API validator.
import fs from 'node:fs';
import crypto from 'node:crypto';
const base = new URL('../contracts/', import.meta.url);
const schema = JSON.parse(fs.readFileSync(new URL('content-v1.schema.json', base), 'utf8'));
const vectors = JSON.parse(fs.readFileSync(new URL('hash-vectors-v1.json', base), 'utf8'));
const resolve = s => s.$ref ? schema.$defs[s.$ref.split('/').at(-1)] : s;
function choose(v, s) {
  s = resolve(s);
  if (s.oneOf) return choose(v, s.oneOf.find(x => x.properties.object_type.const === v.object_type));
  if (s.anyOf) {
    const t = v === null ? 'null' : Array.isArray(v) ? 'array' : typeof v === 'number' ? 'integer' : typeof v;
    return choose(v, s.anyOf.find(x => resolve(x).type === t));
  }
  return s;
}
function canon(v) {
  if (Array.isArray(v)) return '[' + v.map(canon).join(',') + ']';
  if (v !== null && typeof v === 'object') return '{' + Object.keys(v).sort().map(k => JSON.stringify(k) + ':' + canon(v[k])).join(',') + '}';
  if (typeof v === 'number' && (!Number.isSafeInteger(v) || Object.is(v, -0))) throw Error('invalid number');
  return JSON.stringify(v);
}
function norm(v, s) {
  s = choose(v, s);
  if (s.type === 'object') return Object.fromEntries(Object.entries(v).map(([k,x]) => [k,norm(x,s.properties?.[k] ?? s.additionalProperties)]));
  if (s.type === 'array') {
    const items = v.map(x => norm(x,s.items));
    if (s['x-order'] === 'set') {
      const key = x => s['x-sort-keys'] ? s['x-sort-keys'].map(k => String(x[k])) : [canon(x)];
      const compare = (a,b) => {
        const ka=key(a),kb=key(b);
        for(let i=0;i<ka.length;i++) {
          const d=s['x-sort-keys'] ? (ka[i]<kb[i]?-1:ka[i]>kb[i]?1:0) : Buffer.compare(Buffer.from(ka[i]),Buffer.from(kb[i]));
          if(d) return d;
        }
        return 0;
      };
      items.sort(compare);
      for(let i=1;i<items.length;i++) if(compare(items[i-1],items[i])===0) throw Error('duplicate set');
    }
    return items;
  }
  return v;
}
let count=0;
for(const test of vectors.valid) {
  const encoded=canon(norm(JSON.parse(test.input_json),schema));
  const hash=crypto.createHash('sha256').update(encoded,'utf8').digest('hex');
  if(encoded!==test.canonical_utf8 || hash!==test.sha256) throw Error(test.name+' mismatch');
  count++;
}
console.log(JSON.stringify({javascript_valid_vectors:count,status:'PASS'}));
